UNDANGAN WEBSITE HABIB & ADIBA

Cara mencoba:
1. Buka index.html di browser.
2. Website sudah dibuat responsif untuk HP.
3. Folder assets berisi foto yang diambil dari video referensi.

Cara membuatnya online:
- Upload seluruh isi folder ini ke layanan hosting static website.
- Pastikan index.html berada di folder utama.

Yang bisa diganti:
- Nama, tanggal, jam, alamat, dan teks di index.html.
- Foto di folder assets.
- Tambahkan file musik MP3 ke assets dan isi src pada tag <audio>.
